xterm -e dosbox KIDPIX.EXE
